// Sabina Kowalczyk, Zintergrowane systemy zarzadzania i analizy danych, 101496

<<<<<<< HEAD
<<<<<<< HEAD

void pytanie() 
{	
	cout<<"Q1) Jak wyswietlic roznice miedzy drugim a trzecim zatwierdzeniem wykonanym w galezi master?"<<endl;	
	cout<<"A1) git HEAD^^^ HEAD^^"<<endl;
	
	cout<<"Q2) Co sie zmienilo?"<<endl;	
	cout<<"A2) ..."<<endl;
}

#include <iostream>
using namespace std;

int main(int argc, char **argv) {
<<<<<<< HEAD
  cout<<"I love git!"<<endl;
=======
  cout<<"I don't like git"<<endl;
>>>>>>> cplusplus
  pytanie();
}

